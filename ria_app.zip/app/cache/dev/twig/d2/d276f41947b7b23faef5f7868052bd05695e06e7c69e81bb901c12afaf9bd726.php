<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_7e92777f0bc09b32ea23efdde8ab606c4bf9bcaa7cedb6c3ea3e5b3618854313 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e49a102dbd6f66b4d791ea6cf2242fe7cadcfe4cc9832836efdc5d8920a0524 = $this->env->getExtension("native_profiler");
        $__internal_6e49a102dbd6f66b4d791ea6cf2242fe7cadcfe4cc9832836efdc5d8920a0524->enter($__internal_6e49a102dbd6f66b4d791ea6cf2242fe7cadcfe4cc9832836efdc5d8920a0524_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("TwigBundle:Exception:exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_6e49a102dbd6f66b4d791ea6cf2242fe7cadcfe4cc9832836efdc5d8920a0524->leave($__internal_6e49a102dbd6f66b4d791ea6cf2242fe7cadcfe4cc9832836efdc5d8920a0524_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include 'TwigBundle:Exception:exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
