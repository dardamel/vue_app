<?php

/* AppMainBundle:Category:edit.html.twig */
class __TwigTemplate_d6cabf8a2737a00e790daa432de3f9af407e4bd5f92b49932d1fd74dc189f67d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppMainBundle:Category:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ade6c75c11b706b3e31bef24f1c56be964ebbad0086cd81940728ca82d9b0376 = $this->env->getExtension("native_profiler");
        $__internal_ade6c75c11b706b3e31bef24f1c56be964ebbad0086cd81940728ca82d9b0376->enter($__internal_ade6c75c11b706b3e31bef24f1c56be964ebbad0086cd81940728ca82d9b0376_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Category:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ade6c75c11b706b3e31bef24f1c56be964ebbad0086cd81940728ca82d9b0376->leave($__internal_ade6c75c11b706b3e31bef24f1c56be964ebbad0086cd81940728ca82d9b0376_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_85c07ef066734fc8a0764d4e54400f9e4bc8f762af078145d6e8b75733f768d7 = $this->env->getExtension("native_profiler");
        $__internal_85c07ef066734fc8a0764d4e54400f9e4bc8f762af078145d6e8b75733f768d7->enter($__internal_85c07ef066734fc8a0764d4e54400f9e4bc8f762af078145d6e8b75733f768d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Category edit</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("admin_category");
        echo "\">
            Back to the list
        </a>
    </li>
    <li>";
        // line 14
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form');
        echo "</li>
</ul>
";
        
        $__internal_85c07ef066734fc8a0764d4e54400f9e4bc8f762af078145d6e8b75733f768d7->leave($__internal_85c07ef066734fc8a0764d4e54400f9e4bc8f762af078145d6e8b75733f768d7_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Category:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 14,  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends '::base.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Category edit</h1>*/
/* */
/*     {{ form(edit_form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('admin_category') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/*     <li>{{ form(delete_form) }}</li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
