<?php

/* AppMainBundle:Default:index.html.twig */
class __TwigTemplate_464ba419c7e951371acf1a4199ccd8f003d058d08baf9fabfd83d9269a4c47df extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a4196a8bb4d06b962475b2bf290f9cabf7ac96be508a7de48e465477669cae23 = $this->env->getExtension("native_profiler");
        $__internal_a4196a8bb4d06b962475b2bf290f9cabf7ac96be508a7de48e465477669cae23->enter($__internal_a4196a8bb4d06b962475b2bf290f9cabf7ac96be508a7de48e465477669cae23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Default:index.html.twig"));

        // line 1
        echo "Hello ";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "!
";
        
        $__internal_a4196a8bb4d06b962475b2bf290f9cabf7ac96be508a7de48e465477669cae23->leave($__internal_a4196a8bb4d06b962475b2bf290f9cabf7ac96be508a7de48e465477669cae23_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello {{ name }}!*/
/* */
