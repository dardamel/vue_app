<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_e3c5d0ee074e25a5ccb915af60d426cfaf88b48a7032874e7c02ecc3d8b9e415 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7a149b0a590e568a989eda1cbc3bbfc35a5ba2e037e775b19484abbe1d424263 = $this->env->getExtension("native_profiler");
        $__internal_7a149b0a590e568a989eda1cbc3bbfc35a5ba2e037e775b19484abbe1d424263->enter($__internal_7a149b0a590e568a989eda1cbc3bbfc35a5ba2e037e775b19484abbe1d424263_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_7a149b0a590e568a989eda1cbc3bbfc35a5ba2e037e775b19484abbe1d424263->leave($__internal_7a149b0a590e568a989eda1cbc3bbfc35a5ba2e037e775b19484abbe1d424263_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
