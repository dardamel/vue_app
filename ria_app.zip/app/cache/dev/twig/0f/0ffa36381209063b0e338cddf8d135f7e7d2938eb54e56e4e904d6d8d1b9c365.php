<?php

/* ::base.html.twig */
class __TwigTemplate_bff753809cad1eda2372b20d66fd10997f6525d3175a4ec4934c1ce07f8c0b48 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_36236d0968dad8c3628a2cefdfe40bc74a0b18ca96b4e714554a395c44243a57 = $this->env->getExtension("native_profiler");
        $__internal_36236d0968dad8c3628a2cefdfe40bc74a0b18ca96b4e714554a395c44243a57->enter($__internal_36236d0968dad8c3628a2cefdfe40bc74a0b18ca96b4e714554a395c44243a57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_36236d0968dad8c3628a2cefdfe40bc74a0b18ca96b4e714554a395c44243a57->leave($__internal_36236d0968dad8c3628a2cefdfe40bc74a0b18ca96b4e714554a395c44243a57_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_ac35be07852ccdf5f37048794eb4ea364cf958ad86dbc03f3db7e8f558a7c0d1 = $this->env->getExtension("native_profiler");
        $__internal_ac35be07852ccdf5f37048794eb4ea364cf958ad86dbc03f3db7e8f558a7c0d1->enter($__internal_ac35be07852ccdf5f37048794eb4ea364cf958ad86dbc03f3db7e8f558a7c0d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_ac35be07852ccdf5f37048794eb4ea364cf958ad86dbc03f3db7e8f558a7c0d1->leave($__internal_ac35be07852ccdf5f37048794eb4ea364cf958ad86dbc03f3db7e8f558a7c0d1_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0a8df5a94ccb302d90a695b45a39fcd4c5c8ffc8c7ab6dc24b848ac38e6e47dc = $this->env->getExtension("native_profiler");
        $__internal_0a8df5a94ccb302d90a695b45a39fcd4c5c8ffc8c7ab6dc24b848ac38e6e47dc->enter($__internal_0a8df5a94ccb302d90a695b45a39fcd4c5c8ffc8c7ab6dc24b848ac38e6e47dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_0a8df5a94ccb302d90a695b45a39fcd4c5c8ffc8c7ab6dc24b848ac38e6e47dc->leave($__internal_0a8df5a94ccb302d90a695b45a39fcd4c5c8ffc8c7ab6dc24b848ac38e6e47dc_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_e1a3329cfeb6a547ab8bf97e2589e272486ddc20e5dbe990d1cbe36644aa19b5 = $this->env->getExtension("native_profiler");
        $__internal_e1a3329cfeb6a547ab8bf97e2589e272486ddc20e5dbe990d1cbe36644aa19b5->enter($__internal_e1a3329cfeb6a547ab8bf97e2589e272486ddc20e5dbe990d1cbe36644aa19b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_e1a3329cfeb6a547ab8bf97e2589e272486ddc20e5dbe990d1cbe36644aa19b5->leave($__internal_e1a3329cfeb6a547ab8bf97e2589e272486ddc20e5dbe990d1cbe36644aa19b5_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c964daee94a17ec82f82165520bb22170f586d328d1052837294fde874f6bd19 = $this->env->getExtension("native_profiler");
        $__internal_c964daee94a17ec82f82165520bb22170f586d328d1052837294fde874f6bd19->enter($__internal_c964daee94a17ec82f82165520bb22170f586d328d1052837294fde874f6bd19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_c964daee94a17ec82f82165520bb22170f586d328d1052837294fde874f6bd19->leave($__internal_c964daee94a17ec82f82165520bb22170f586d328d1052837294fde874f6bd19_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
