<?php

/* AppMainBundle:Admin:index.html.twig */
class __TwigTemplate_b67fc064eefdc308b388951c8f0a21e2965d815724828a9c80e1fda842e8e84c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0d1bbc06f33c5a801009041f68dd170802220c9f3ef3b6081e560990d8204d38 = $this->env->getExtension("native_profiler");
        $__internal_0d1bbc06f33c5a801009041f68dd170802220c9f3ef3b6081e560990d8204d38->enter($__internal_0d1bbc06f33c5a801009041f68dd170802220c9f3ef3b6081e560990d8204d38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Admin:index.html.twig"));

        // line 1
        echo "<h1>Zarządzanie</h1>

<a href=\"";
        // line 3
        echo $this->env->getExtension('routing')->getPath("admin_article");
        echo "\">Artykuły</a><br />
<a href=\"";
        // line 4
        echo $this->env->getExtension('routing')->getPath("admin_category");
        echo "\">Kategorie</a><br/>
<a href=\"";
        // line 5
        echo $this->env->getExtension('routing')->getPath("admin_contact");
        echo "\">Kontakt</a><br/>";
        
        $__internal_0d1bbc06f33c5a801009041f68dd170802220c9f3ef3b6081e560990d8204d38->leave($__internal_0d1bbc06f33c5a801009041f68dd170802220c9f3ef3b6081e560990d8204d38_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Admin:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 5,  30 => 4,  26 => 3,  22 => 1,);
    }
}
/* <h1>Zarządzanie</h1>*/
/* */
/* <a href="{{ path('admin_article') }}">Artykuły</a><br />*/
/* <a href="{{ path('admin_category') }}">Kategorie</a><br/>*/
/* <a href="{{ path('admin_contact') }}">Kontakt</a><br/>*/
