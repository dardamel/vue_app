<?php

/* AppMainBundle:Category:show.html.twig */
class __TwigTemplate_a1d4109ca49908e8fd94e43eca87be956adb7b79ae320fcc7a7aba2f0d51b86c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppMainBundle:Category:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca987eef2b62dfd7c770105c28e511c6976ae57794bef9638b6ce8949c11cf17 = $this->env->getExtension("native_profiler");
        $__internal_ca987eef2b62dfd7c770105c28e511c6976ae57794bef9638b6ce8949c11cf17->enter($__internal_ca987eef2b62dfd7c770105c28e511c6976ae57794bef9638b6ce8949c11cf17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Category:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ca987eef2b62dfd7c770105c28e511c6976ae57794bef9638b6ce8949c11cf17->leave($__internal_ca987eef2b62dfd7c770105c28e511c6976ae57794bef9638b6ce8949c11cf17_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_4fa6997bdf8d0ea69184f8d6cc1f254930dcf65e32bcbbab444ce9b8b0261845 = $this->env->getExtension("native_profiler");
        $__internal_4fa6997bdf8d0ea69184f8d6cc1f254930dcf65e32bcbbab444ce9b8b0261845->enter($__internal_4fa6997bdf8d0ea69184f8d6cc1f254930dcf65e32bcbbab444ce9b8b0261845_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Category</h1>

    <table class=\"record_properties\">
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["entity"]) ? $context["entity"] : $this->getContext($context, "entity")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Name</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["entity"]) ? $context["entity"] : $this->getContext($context, "entity")), "name", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Link</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["entity"]) ? $context["entity"] : $this->getContext($context, "entity")), "link", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("admin_category");
        echo "\">
            Back to the list
        </a>
    </li>
    <li>
        <a href=\"";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_category_edit", array("id" => $this->getAttribute((isset($context["entity"]) ? $context["entity"] : $this->getContext($context, "entity")), "id", array()))), "html", null, true);
        echo "\">
            Edit
        </a>
    </li>
    <li>";
        // line 34
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form');
        echo "</li>
</ul>
";
        
        $__internal_4fa6997bdf8d0ea69184f8d6cc1f254930dcf65e32bcbbab444ce9b8b0261845->leave($__internal_4fa6997bdf8d0ea69184f8d6cc1f254930dcf65e32bcbbab444ce9b8b0261845_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Category:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 34,  80 => 30,  72 => 25,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends '::base.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Category</h1>*/
/* */
/*     <table class="record_properties">*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <td>{{ entity.id }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Name</th>*/
/*                 <td>{{ entity.name }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Link</th>*/
/*                 <td>{{ entity.link }}</td>*/
/*             </tr>*/
/*         </tbody>*/
/*     </table>*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('admin_category') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/*     <li>*/
/*         <a href="{{ path('admin_category_edit', { 'id': entity.id }) }}">*/
/*             Edit*/
/*         </a>*/
/*     </li>*/
/*     <li>{{ form(delete_form) }}</li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
