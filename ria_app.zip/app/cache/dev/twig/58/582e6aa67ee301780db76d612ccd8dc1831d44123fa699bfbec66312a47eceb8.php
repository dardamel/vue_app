<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_7f1cf01d689fe45ac78e54e4d5d92255e89d03b7594ba442690750a32ed0d298 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d1fce007659ed6655d2ba7f9b573ee858d0cc81d9ecf85c098df526962347afc = $this->env->getExtension("native_profiler");
        $__internal_d1fce007659ed6655d2ba7f9b573ee858d0cc81d9ecf85c098df526962347afc->enter($__internal_d1fce007659ed6655d2ba7f9b573ee858d0cc81d9ecf85c098df526962347afc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_d1fce007659ed6655d2ba7f9b573ee858d0cc81d9ecf85c098df526962347afc->leave($__internal_d1fce007659ed6655d2ba7f9b573ee858d0cc81d9ecf85c098df526962347afc_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:error.xml.twig' %}*/
/* */
