<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_de50c0ccc039db4bcb32140fd4101b61eaf94f6fcfe0eb651473ae12b4cbd2ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e02aa9bd8aa23021677aefb5b32d7f284e1ca99e6986a0a6e3c121aea1527d0 = $this->env->getExtension("native_profiler");
        $__internal_7e02aa9bd8aa23021677aefb5b32d7f284e1ca99e6986a0a6e3c121aea1527d0->enter($__internal_7e02aa9bd8aa23021677aefb5b32d7f284e1ca99e6986a0a6e3c121aea1527d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_7e02aa9bd8aa23021677aefb5b32d7f284e1ca99e6986a0a6e3c121aea1527d0->leave($__internal_7e02aa9bd8aa23021677aefb5b32d7f284e1ca99e6986a0a6e3c121aea1527d0_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:exception.xml.twig' with { 'exception': exception } %}*/
/* */
