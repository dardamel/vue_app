<?php

/* SensioDistributionBundle::Configurator/layout.html.twig */
class __TwigTemplate_2df7bc871892166140795e19e8782535441d91f72a5c18a3823f3ba288b5c256 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "SensioDistributionBundle::Configurator/layout.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c83542214a4e5f07dffef063e96c942565ccff6bec6bbc58227725ba0e5c6373 = $this->env->getExtension("native_profiler");
        $__internal_c83542214a4e5f07dffef063e96c942565ccff6bec6bbc58227725ba0e5c6373->enter($__internal_c83542214a4e5f07dffef063e96c942565ccff6bec6bbc58227725ba0e5c6373_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SensioDistributionBundle::Configurator/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c83542214a4e5f07dffef063e96c942565ccff6bec6bbc58227725ba0e5c6373->leave($__internal_c83542214a4e5f07dffef063e96c942565ccff6bec6bbc58227725ba0e5c6373_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_c3d97804433f7d9ffb06292a652b27c5247c751572b948e491b9ff99e359229c = $this->env->getExtension("native_profiler");
        $__internal_c3d97804433f7d9ffb06292a652b27c5247c751572b948e491b9ff99e359229c->enter($__internal_c3d97804433f7d9ffb06292a652b27c5247c751572b948e491b9ff99e359229c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/sensiodistribution/webconfigurator/css/configurator.css"), "html", null, true);
        echo "\" />
";
        
        $__internal_c3d97804433f7d9ffb06292a652b27c5247c751572b948e491b9ff99e359229c->leave($__internal_c3d97804433f7d9ffb06292a652b27c5247c751572b948e491b9ff99e359229c_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_f8da25eeb5c38f751383f0a863e05a64f8e711d06665e10179fa20ae277cc0bb = $this->env->getExtension("native_profiler");
        $__internal_f8da25eeb5c38f751383f0a863e05a64f8e711d06665e10179fa20ae277cc0bb->enter($__internal_f8da25eeb5c38f751383f0a863e05a64f8e711d06665e10179fa20ae277cc0bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Web Configurator Bundle";
        
        $__internal_f8da25eeb5c38f751383f0a863e05a64f8e711d06665e10179fa20ae277cc0bb->leave($__internal_f8da25eeb5c38f751383f0a863e05a64f8e711d06665e10179fa20ae277cc0bb_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_218cfc3ffea0857c989bf2fa3878c774bf30c91fcf5c3c8f52cc30cc0545405d = $this->env->getExtension("native_profiler");
        $__internal_218cfc3ffea0857c989bf2fa3878c774bf30c91fcf5c3c8f52cc30cc0545405d->enter($__internal_218cfc3ffea0857c989bf2fa3878c774bf30c91fcf5c3c8f52cc30cc0545405d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    <div class=\"block\">
        ";
        // line 11
        $this->displayBlock('content', $context, $blocks);
        // line 12
        echo "    </div>
    <div class=\"version\">Symfony Standard Edition v.";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["version"]) ? $context["version"] : $this->getContext($context, "version")), "html", null, true);
        echo "</div>
";
        
        $__internal_218cfc3ffea0857c989bf2fa3878c774bf30c91fcf5c3c8f52cc30cc0545405d->leave($__internal_218cfc3ffea0857c989bf2fa3878c774bf30c91fcf5c3c8f52cc30cc0545405d_prof);

    }

    // line 11
    public function block_content($context, array $blocks = array())
    {
        $__internal_325bfe92523c92938217765009799107f4fb23e65de72c9831835451976327d9 = $this->env->getExtension("native_profiler");
        $__internal_325bfe92523c92938217765009799107f4fb23e65de72c9831835451976327d9->enter($__internal_325bfe92523c92938217765009799107f4fb23e65de72c9831835451976327d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_325bfe92523c92938217765009799107f4fb23e65de72c9831835451976327d9->leave($__internal_325bfe92523c92938217765009799107f4fb23e65de72c9831835451976327d9_prof);

    }

    public function getTemplateName()
    {
        return "SensioDistributionBundle::Configurator/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 11,  79 => 13,  76 => 12,  74 => 11,  71 => 10,  65 => 9,  53 => 7,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends "TwigBundle::layout.html.twig" %}*/
/* */
/* {% block head %}*/
/*     <link rel="stylesheet" href="{{ asset('bundles/sensiodistribution/webconfigurator/css/configurator.css') }}" />*/
/* {% endblock %}*/
/* */
/* {% block title 'Web Configurator Bundle' %}*/
/* */
/* {% block body %}*/
/*     <div class="block">*/
/*         {% block content %}{% endblock %}*/
/*     </div>*/
/*     <div class="version">Symfony Standard Edition v.{{ version }}</div>*/
/* {% endblock %}*/
/* */
