<?php

/* AppMainBundle:Article:edit.html.twig */
class __TwigTemplate_6f31af9ae035127a912a28eec00c780b4880e57085b729218f0ec3a2c8830b15 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppMainBundle:Article:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_edaa21b1f9414f566e128cc051dbd141d2a476483d09c880b3f1bcd26f02e67c = $this->env->getExtension("native_profiler");
        $__internal_edaa21b1f9414f566e128cc051dbd141d2a476483d09c880b3f1bcd26f02e67c->enter($__internal_edaa21b1f9414f566e128cc051dbd141d2a476483d09c880b3f1bcd26f02e67c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Article:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_edaa21b1f9414f566e128cc051dbd141d2a476483d09c880b3f1bcd26f02e67c->leave($__internal_edaa21b1f9414f566e128cc051dbd141d2a476483d09c880b3f1bcd26f02e67c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_ece164123955fb17a904df8fad2d59697712352823b6fb52cb0f4a5c6f74e83b = $this->env->getExtension("native_profiler");
        $__internal_ece164123955fb17a904df8fad2d59697712352823b6fb52cb0f4a5c6f74e83b->enter($__internal_ece164123955fb17a904df8fad2d59697712352823b6fb52cb0f4a5c6f74e83b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Article edit</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("admin_article");
        echo "\">
            Back to the list
        </a>
    </li>
    <li>";
        // line 14
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form');
        echo "</li>
</ul>
";
        
        $__internal_ece164123955fb17a904df8fad2d59697712352823b6fb52cb0f4a5c6f74e83b->leave($__internal_ece164123955fb17a904df8fad2d59697712352823b6fb52cb0f4a5c6f74e83b_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Article:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 14,  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends '::base.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Article edit</h1>*/
/* */
/*     {{ form(edit_form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('admin_article') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/*     <li>{{ form(delete_form) }}</li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
