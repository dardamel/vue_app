<?php

/* AppMainBundle:Article:home.html.twig */
class __TwigTemplate_4a9e6d3454fee991efccdb32ca8d28dd21762149452843d5dbff4e8cc37dae5a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppMainBundle:Article:home.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b714f5543742444789d31cca9bad42c92e27e55bd61e33edbdf3432b23254842 = $this->env->getExtension("native_profiler");
        $__internal_b714f5543742444789d31cca9bad42c92e27e55bd61e33edbdf3432b23254842->enter($__internal_b714f5543742444789d31cca9bad42c92e27e55bd61e33edbdf3432b23254842_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Article:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b714f5543742444789d31cca9bad42c92e27e55bd61e33edbdf3432b23254842->leave($__internal_b714f5543742444789d31cca9bad42c92e27e55bd61e33edbdf3432b23254842_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_83a3c16325a2da0ec8851b4d7f34ebed991d6281dd76903a5076ae3410d4a934 = $this->env->getExtension("native_profiler");
        $__internal_83a3c16325a2da0ec8851b4d7f34ebed991d6281dd76903a5076ae3410d4a934->enter($__internal_83a3c16325a2da0ec8851b4d7f34ebed991d6281dd76903a5076ae3410d4a934_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "AppMainBundle:Article:home";
        
        $__internal_83a3c16325a2da0ec8851b4d7f34ebed991d6281dd76903a5076ae3410d4a934->leave($__internal_83a3c16325a2da0ec8851b4d7f34ebed991d6281dd76903a5076ae3410d4a934_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_7d285aa759b8a8b296433b94082856ef3df7c906df4090db0073f50a270683ca = $this->env->getExtension("native_profiler");
        $__internal_7d285aa759b8a8b296433b94082856ef3df7c906df4090db0073f50a270683ca->enter($__internal_7d285aa759b8a8b296433b94082856ef3df7c906df4090db0073f50a270683ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>Welcome to the Article:home page</h1>
";
        
        $__internal_7d285aa759b8a8b296433b94082856ef3df7c906df4090db0073f50a270683ca->leave($__internal_7d285aa759b8a8b296433b94082856ef3df7c906df4090db0073f50a270683ca_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Article:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block title %}AppMainBundle:Article:home{% endblock %}*/
/* */
/* {% block body %}*/
/* <h1>Welcome to the Article:home page</h1>*/
/* {% endblock %}*/
/* */
