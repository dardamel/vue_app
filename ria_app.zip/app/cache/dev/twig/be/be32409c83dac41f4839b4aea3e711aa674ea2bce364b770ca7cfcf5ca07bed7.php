<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_c0f6dbdad5edeea099981d9c5186c39ff5650a6f8d22810ff903ca9b3363f3c6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_852a57a64bf30341712d15a34300ae9ea4a2bd2c0dab7edd91608321cb9c7df5 = $this->env->getExtension("native_profiler");
        $__internal_852a57a64bf30341712d15a34300ae9ea4a2bd2c0dab7edd91608321cb9c7df5->enter($__internal_852a57a64bf30341712d15a34300ae9ea4a2bd2c0dab7edd91608321cb9c7df5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("TwigBundle:Exception:exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_852a57a64bf30341712d15a34300ae9ea4a2bd2c0dab7edd91608321cb9c7df5->leave($__internal_852a57a64bf30341712d15a34300ae9ea4a2bd2c0dab7edd91608321cb9c7df5_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include 'TwigBundle:Exception:exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
