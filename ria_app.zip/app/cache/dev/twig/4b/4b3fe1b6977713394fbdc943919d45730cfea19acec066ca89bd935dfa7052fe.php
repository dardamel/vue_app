<?php

/* AppMainBundle:Category:new.html.twig */
class __TwigTemplate_994097316854b4c90303639afa7e16aad5f6d925c9c811504e4866e04e4c5286 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppMainBundle:Category:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4c7a720f14aefc7418c38aba5bc80c108e308344dff4ccda9afa60d17f01ec09 = $this->env->getExtension("native_profiler");
        $__internal_4c7a720f14aefc7418c38aba5bc80c108e308344dff4ccda9afa60d17f01ec09->enter($__internal_4c7a720f14aefc7418c38aba5bc80c108e308344dff4ccda9afa60d17f01ec09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Category:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4c7a720f14aefc7418c38aba5bc80c108e308344dff4ccda9afa60d17f01ec09->leave($__internal_4c7a720f14aefc7418c38aba5bc80c108e308344dff4ccda9afa60d17f01ec09_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_df28bfafd184344855d603325139e8422bf2626bac90a0a2cf2232386b1bbd10 = $this->env->getExtension("native_profiler");
        $__internal_df28bfafd184344855d603325139e8422bf2626bac90a0a2cf2232386b1bbd10->enter($__internal_df28bfafd184344855d603325139e8422bf2626bac90a0a2cf2232386b1bbd10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Category creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("admin_category");
        echo "\">
            Back to the list
        </a>
    </li>
</ul>
";
        
        $__internal_df28bfafd184344855d603325139e8422bf2626bac90a0a2cf2232386b1bbd10->leave($__internal_df28bfafd184344855d603325139e8422bf2626bac90a0a2cf2232386b1bbd10_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Category:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends '::base.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Category creation</h1>*/
/* */
/*     {{ form(form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('admin_category') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
