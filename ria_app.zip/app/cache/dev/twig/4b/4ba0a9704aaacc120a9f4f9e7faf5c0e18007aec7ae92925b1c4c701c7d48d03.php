<?php

/* AppMainBundle:Article:list.html.twig */
class __TwigTemplate_a5511478443efad175b3fb0dc785e368d57a669c99237a189b11d2e25715f92c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppMainBundle:Article:list.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_82f9dc6d92ea59be8db25633a07e23cc1fb6ea389632e8b231a4718ae9dcb38c = $this->env->getExtension("native_profiler");
        $__internal_82f9dc6d92ea59be8db25633a07e23cc1fb6ea389632e8b231a4718ae9dcb38c->enter($__internal_82f9dc6d92ea59be8db25633a07e23cc1fb6ea389632e8b231a4718ae9dcb38c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Article:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_82f9dc6d92ea59be8db25633a07e23cc1fb6ea389632e8b231a4718ae9dcb38c->leave($__internal_82f9dc6d92ea59be8db25633a07e23cc1fb6ea389632e8b231a4718ae9dcb38c_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_748bd0b05f1ee995dc3ec412cd74d1a149d604b440127df35f568f8150912092 = $this->env->getExtension("native_profiler");
        $__internal_748bd0b05f1ee995dc3ec412cd74d1a149d604b440127df35f568f8150912092->enter($__internal_748bd0b05f1ee995dc3ec412cd74d1a149d604b440127df35f568f8150912092_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "AppMainBundle:Article:list";
        
        $__internal_748bd0b05f1ee995dc3ec412cd74d1a149d604b440127df35f568f8150912092->leave($__internal_748bd0b05f1ee995dc3ec412cd74d1a149d604b440127df35f568f8150912092_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_c280662b99424605ba8a08ab41fc57132aa282a8215c6b76f7715a121d848108 = $this->env->getExtension("native_profiler");
        $__internal_c280662b99424605ba8a08ab41fc57132aa282a8215c6b76f7715a121d848108->enter($__internal_c280662b99424605ba8a08ab41fc57132aa282a8215c6b76f7715a121d848108_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<h1>Welcome to the Article:list page</h1>
";
        
        $__internal_c280662b99424605ba8a08ab41fc57132aa282a8215c6b76f7715a121d848108->leave($__internal_c280662b99424605ba8a08ab41fc57132aa282a8215c6b76f7715a121d848108_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Article:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block title %}AppMainBundle:Article:list{% endblock %}*/
/* */
/* {% block body %}*/
/* <h1>Welcome to the Article:list page</h1>*/
/* {% endblock %}*/
/* */
