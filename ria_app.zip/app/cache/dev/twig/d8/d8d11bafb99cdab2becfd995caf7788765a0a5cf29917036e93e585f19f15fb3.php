<?php

/* AppMainBundle:Article:new.html.twig */
class __TwigTemplate_50d115c8f46e0d080ba313834f9f0f7be0ce788dfd44586ecb8bdcc6699832a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppMainBundle:Article:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d9d76876b3d3af26c410bd5d3c97972881bb07cc6c214fc879fc04d77a7beaad = $this->env->getExtension("native_profiler");
        $__internal_d9d76876b3d3af26c410bd5d3c97972881bb07cc6c214fc879fc04d77a7beaad->enter($__internal_d9d76876b3d3af26c410bd5d3c97972881bb07cc6c214fc879fc04d77a7beaad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Article:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d9d76876b3d3af26c410bd5d3c97972881bb07cc6c214fc879fc04d77a7beaad->leave($__internal_d9d76876b3d3af26c410bd5d3c97972881bb07cc6c214fc879fc04d77a7beaad_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_e28502d9b13017e1874d9e329ac07f43d74bb7e85a70ec69f5f33f07a8f292e7 = $this->env->getExtension("native_profiler");
        $__internal_e28502d9b13017e1874d9e329ac07f43d74bb7e85a70ec69f5f33f07a8f292e7->enter($__internal_e28502d9b13017e1874d9e329ac07f43d74bb7e85a70ec69f5f33f07a8f292e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Article creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("admin_article");
        echo "\">
            Back to the list
        </a>
    </li>
</ul>
";
        
        $__internal_e28502d9b13017e1874d9e329ac07f43d74bb7e85a70ec69f5f33f07a8f292e7->leave($__internal_e28502d9b13017e1874d9e329ac07f43d74bb7e85a70ec69f5f33f07a8f292e7_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Article:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends '::base.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Article creation</h1>*/
/* */
/*     {{ form(form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('admin_article') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
