<?php

/* AppMainBundle:Contact:new.html.twig */
class __TwigTemplate_bec9ea2a7db726ab6ed0f58a33478182ea878f35846f2ee6e768fc04357b9ddd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppMainBundle:Contact:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aebe8662ce342c302b345d830dbd4ad444f85749e0f350767a99cfbcf5adce75 = $this->env->getExtension("native_profiler");
        $__internal_aebe8662ce342c302b345d830dbd4ad444f85749e0f350767a99cfbcf5adce75->enter($__internal_aebe8662ce342c302b345d830dbd4ad444f85749e0f350767a99cfbcf5adce75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Contact:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aebe8662ce342c302b345d830dbd4ad444f85749e0f350767a99cfbcf5adce75->leave($__internal_aebe8662ce342c302b345d830dbd4ad444f85749e0f350767a99cfbcf5adce75_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_015f0579f28345ab43b64360029a31e6a517fa4cae83edc1c0e5f869a3c2a41e = $this->env->getExtension("native_profiler");
        $__internal_015f0579f28345ab43b64360029a31e6a517fa4cae83edc1c0e5f869a3c2a41e->enter($__internal_015f0579f28345ab43b64360029a31e6a517fa4cae83edc1c0e5f869a3c2a41e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Contact creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("admin_contact");
        echo "\">
            Back to the list
        </a>
    </li>
</ul>
";
        
        $__internal_015f0579f28345ab43b64360029a31e6a517fa4cae83edc1c0e5f869a3c2a41e->leave($__internal_015f0579f28345ab43b64360029a31e6a517fa4cae83edc1c0e5f869a3c2a41e_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Contact:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends '::base.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Contact creation</h1>*/
/* */
/*     {{ form(form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('admin_contact') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
