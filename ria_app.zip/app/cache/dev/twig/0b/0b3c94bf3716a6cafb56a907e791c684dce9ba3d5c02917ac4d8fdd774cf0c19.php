<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_81eb57150e2a4f5ba851f12faf2c8b50d5460ba9ef6a7c13d5b16e8847ae0af4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ac5034c60fe77923a66049607ffa9e2a3c1a053bdaccb9c6ebce8cc4cd91c371 = $this->env->getExtension("native_profiler");
        $__internal_ac5034c60fe77923a66049607ffa9e2a3c1a053bdaccb9c6ebce8cc4cd91c371->enter($__internal_ac5034c60fe77923a66049607ffa9e2a3c1a053bdaccb9c6ebce8cc4cd91c371_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("TwigBundle:Exception:error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_ac5034c60fe77923a66049607ffa9e2a3c1a053bdaccb9c6ebce8cc4cd91c371->leave($__internal_ac5034c60fe77923a66049607ffa9e2a3c1a053bdaccb9c6ebce8cc4cd91c371_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include 'TwigBundle:Exception:error.xml.twig' %}*/
/* */
