<?php

/* AppMainBundle:Contact:edit.html.twig */
class __TwigTemplate_bad5cf1b45c6d2375b478ce124bcb99168052dea2a6f69ce9733c2aa719fc7eb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppMainBundle:Contact:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7210d241182743da2c6311f85fb15c4425fa9044cef51550e33814193355b9f2 = $this->env->getExtension("native_profiler");
        $__internal_7210d241182743da2c6311f85fb15c4425fa9044cef51550e33814193355b9f2->enter($__internal_7210d241182743da2c6311f85fb15c4425fa9044cef51550e33814193355b9f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppMainBundle:Contact:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7210d241182743da2c6311f85fb15c4425fa9044cef51550e33814193355b9f2->leave($__internal_7210d241182743da2c6311f85fb15c4425fa9044cef51550e33814193355b9f2_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_46418a237d904be7b61e67ea66253df4c3028b75be8d533e23e39ece0382dc46 = $this->env->getExtension("native_profiler");
        $__internal_46418a237d904be7b61e67ea66253df4c3028b75be8d533e23e39ece0382dc46->enter($__internal_46418a237d904be7b61e67ea66253df4c3028b75be8d533e23e39ece0382dc46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Contact edit</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("admin_contact");
        echo "\">
            Back to the list
        </a>
    </li>
    <li>";
        // line 14
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form');
        echo "</li>
</ul>
";
        
        $__internal_46418a237d904be7b61e67ea66253df4c3028b75be8d533e23e39ece0382dc46->leave($__internal_46418a237d904be7b61e67ea66253df4c3028b75be8d533e23e39ece0382dc46_prof);

    }

    public function getTemplateName()
    {
        return "AppMainBundle:Contact:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  58 => 14,  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends '::base.html.twig' %}*/
/* */
/* {% block body -%}*/
/*     <h1>Contact edit</h1>*/
/* */
/*     {{ form(edit_form) }}*/
/* */
/*         <ul class="record_actions">*/
/*     <li>*/
/*         <a href="{{ path('admin_contact') }}">*/
/*             Back to the list*/
/*         </a>*/
/*     </li>*/
/*     <li>{{ form(delete_form) }}</li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
