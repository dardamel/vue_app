<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_482cb97683ed4c900741a2bdfed192966f393ab6311c58a5b0c37768aa026f63 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bbe84e124bc1db4eb53f586de23a6b44a73050658963dc889170189ded14262d = $this->env->getExtension("native_profiler");
        $__internal_bbe84e124bc1db4eb53f586de23a6b44a73050658963dc889170189ded14262d->enter($__internal_bbe84e124bc1db4eb53f586de23a6b44a73050658963dc889170189ded14262d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_bbe84e124bc1db4eb53f586de23a6b44a73050658963dc889170189ded14262d->leave($__internal_bbe84e124bc1db4eb53f586de23a6b44a73050658963dc889170189ded14262d_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_7038774d3a5b534ed61c68b31520006b5c4ceb300d37e0e553fbbd65d0019fe3 = $this->env->getExtension("native_profiler");
        $__internal_7038774d3a5b534ed61c68b31520006b5c4ceb300d37e0e553fbbd65d0019fe3->enter($__internal_7038774d3a5b534ed61c68b31520006b5c4ceb300d37e0e553fbbd65d0019fe3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_7038774d3a5b534ed61c68b31520006b5c4ceb300d37e0e553fbbd65d0019fe3->leave($__internal_7038774d3a5b534ed61c68b31520006b5c4ceb300d37e0e553fbbd65d0019fe3_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
