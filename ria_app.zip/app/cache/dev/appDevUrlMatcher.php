<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appDevUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if (rtrim($pathinfo, '/') === '/_profiler') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_profiler_home');
                    }

                    return array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                }

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ($pathinfo === '/_profiler/search') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ($pathinfo === '/_profiler/search_bar') {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_purge
                if ($pathinfo === '/_profiler/purge') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:purgeAction',  '_route' => '_profiler_purge',);
                }

                // _profiler_info
                if (0 === strpos($pathinfo, '/_profiler/info') && preg_match('#^/_profiler/info/(?P<about>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_info')), array (  '_controller' => 'web_profiler.controller.profiler:infoAction',));
                }

                // _profiler_phpinfo
                if ($pathinfo === '/_profiler/phpinfo') {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            if (0 === strpos($pathinfo, '/_configurator')) {
                // _configurator_home
                if (rtrim($pathinfo, '/') === '/_configurator') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', '_configurator_home');
                    }

                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::checkAction',  '_route' => '_configurator_home',);
                }

                // _configurator_step
                if (0 === strpos($pathinfo, '/_configurator/step') && preg_match('#^/_configurator/step/(?P<index>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_configurator_step')), array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::stepAction',));
                }

                // _configurator_final
                if ($pathinfo === '/_configurator/final') {
                    return array (  '_controller' => 'Sensio\\Bundle\\DistributionBundle\\Controller\\ConfiguratorController::finalAction',  '_route' => '_configurator_final',);
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        if (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/c')) {
                if (0 === strpos($pathinfo, '/admin/contact')) {
                    // admin_contact
                    if (rtrim($pathinfo, '/') === '/admin/contact') {
                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'admin_contact');
                        }

                        return array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::indexAction',  '_route' => 'admin_contact',);
                    }

                    // admin_contact_show
                    if (preg_match('#^/admin/contact/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_contact_show')), array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::showAction',));
                    }

                    // admin_contact_new
                    if ($pathinfo === '/admin/contact/new') {
                        return array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::newAction',  '_route' => 'admin_contact_new',);
                    }

                    // admin_contact_create
                    if ($pathinfo === '/admin/contact/create') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_admin_contact_create;
                        }

                        return array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::createAction',  '_route' => 'admin_contact_create',);
                    }
                    not_admin_contact_create:

                    // admin_contact_edit
                    if (preg_match('#^/admin/contact/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_contact_edit')), array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::editAction',));
                    }

                    // admin_contact_update
                    if (preg_match('#^/admin/contact/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                            $allow = array_merge($allow, array('POST', 'PUT'));
                            goto not_admin_contact_update;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_contact_update')), array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::updateAction',));
                    }
                    not_admin_contact_update:

                    // admin_contact_delete
                    if (preg_match('#^/admin/contact/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                            $allow = array_merge($allow, array('POST', 'DELETE'));
                            goto not_admin_contact_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_contact_delete')), array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::deleteAction',));
                    }
                    not_admin_contact_delete:

                }

                if (0 === strpos($pathinfo, '/admin/category')) {
                    // admin_category
                    if (rtrim($pathinfo, '/') === '/admin/category') {
                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'admin_category');
                        }

                        return array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::indexAction',  '_route' => 'admin_category',);
                    }

                    // admin_category_show
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_show')), array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::showAction',));
                    }

                    // admin_category_new
                    if ($pathinfo === '/admin/category/new') {
                        return array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::newAction',  '_route' => 'admin_category_new',);
                    }

                    // admin_category_create
                    if ($pathinfo === '/admin/category/create') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_admin_category_create;
                        }

                        return array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::createAction',  '_route' => 'admin_category_create',);
                    }
                    not_admin_category_create:

                    // admin_category_edit
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_edit')), array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::editAction',));
                    }

                    // admin_category_update
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                            $allow = array_merge($allow, array('POST', 'PUT'));
                            goto not_admin_category_update;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_update')), array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::updateAction',));
                    }
                    not_admin_category_update:

                    // admin_category_delete
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                            $allow = array_merge($allow, array('POST', 'DELETE'));
                            goto not_admin_category_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_delete')), array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::deleteAction',));
                    }
                    not_admin_category_delete:

                }

            }

            if (0 === strpos($pathinfo, '/admin/article')) {
                // admin_article
                if (rtrim($pathinfo, '/') === '/admin/article') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_article');
                    }

                    return array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::indexAction',  '_route' => 'admin_article',);
                }

                // admin_article_show
                if (preg_match('#^/admin/article/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_article_show')), array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::showAction',));
                }

                // admin_article_new
                if ($pathinfo === '/admin/article/new') {
                    return array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::newAction',  '_route' => 'admin_article_new',);
                }

                // admin_article_create
                if ($pathinfo === '/admin/article/create') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_admin_article_create;
                    }

                    return array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::createAction',  '_route' => 'admin_article_create',);
                }
                not_admin_article_create:

                // admin_article_edit
                if (preg_match('#^/admin/article/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_article_edit')), array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::editAction',));
                }

                // admin_article_update
                if (preg_match('#^/admin/article/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                        $allow = array_merge($allow, array('POST', 'PUT'));
                        goto not_admin_article_update;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_article_update')), array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::updateAction',));
                }
                not_admin_article_update:

                // admin_article_delete
                if (preg_match('#^/admin/article/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                        $allow = array_merge($allow, array('POST', 'DELETE'));
                        goto not_admin_article_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_article_delete')), array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::deleteAction',));
                }
                not_admin_article_delete:

            }

            // contact
            if ($pathinfo === '/admin') {
                return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::adminAction',  '_route' => 'contact',);
            }

        }

        // home
        if ($pathinfo === '/home') {
            return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::homeAction',  '_route' => 'home',);
        }

        // list
        if ($pathinfo === '/list') {
            return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::listAction',  '_route' => 'list',);
        }

        // show
        if ($pathinfo === '/show') {
            return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::showAction',  '_route' => 'show',);
        }

        // menu
        if ($pathinfo === '/menu') {
            return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::menuAction',  '_route' => 'menu',);
        }

        // category
        if (0 === strpos($pathinfo, '/category') && preg_match('#^/category/(?P<link>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'category')), array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::categoryAction',));
        }

        // article
        if (0 === strpos($pathinfo, '/article') && preg_match('#^/article/(?P<link>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'article')), array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::articleAction',));
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
