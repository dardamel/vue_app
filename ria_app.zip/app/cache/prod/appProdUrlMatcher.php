<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/c')) {
                if (0 === strpos($pathinfo, '/admin/contact')) {
                    // admin_contact
                    if (rtrim($pathinfo, '/') === '/admin/contact') {
                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'admin_contact');
                        }

                        return array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::indexAction',  '_route' => 'admin_contact',);
                    }

                    // admin_contact_show
                    if (preg_match('#^/admin/contact/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_contact_show')), array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::showAction',));
                    }

                    // admin_contact_new
                    if ($pathinfo === '/admin/contact/new') {
                        return array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::newAction',  '_route' => 'admin_contact_new',);
                    }

                    // admin_contact_create
                    if ($pathinfo === '/admin/contact/create') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_admin_contact_create;
                        }

                        return array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::createAction',  '_route' => 'admin_contact_create',);
                    }
                    not_admin_contact_create:

                    // admin_contact_edit
                    if (preg_match('#^/admin/contact/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_contact_edit')), array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::editAction',));
                    }

                    // admin_contact_update
                    if (preg_match('#^/admin/contact/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                            $allow = array_merge($allow, array('POST', 'PUT'));
                            goto not_admin_contact_update;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_contact_update')), array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::updateAction',));
                    }
                    not_admin_contact_update:

                    // admin_contact_delete
                    if (preg_match('#^/admin/contact/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                            $allow = array_merge($allow, array('POST', 'DELETE'));
                            goto not_admin_contact_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_contact_delete')), array (  '_controller' => 'App\\MainBundle\\Controller\\ContactController::deleteAction',));
                    }
                    not_admin_contact_delete:

                }

                if (0 === strpos($pathinfo, '/admin/category')) {
                    // admin_category
                    if (rtrim($pathinfo, '/') === '/admin/category') {
                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'admin_category');
                        }

                        return array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::indexAction',  '_route' => 'admin_category',);
                    }

                    // admin_category_show
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_show')), array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::showAction',));
                    }

                    // admin_category_new
                    if ($pathinfo === '/admin/category/new') {
                        return array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::newAction',  '_route' => 'admin_category_new',);
                    }

                    // admin_category_create
                    if ($pathinfo === '/admin/category/create') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_admin_category_create;
                        }

                        return array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::createAction',  '_route' => 'admin_category_create',);
                    }
                    not_admin_category_create:

                    // admin_category_edit
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_edit')), array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::editAction',));
                    }

                    // admin_category_update
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                            $allow = array_merge($allow, array('POST', 'PUT'));
                            goto not_admin_category_update;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_update')), array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::updateAction',));
                    }
                    not_admin_category_update:

                    // admin_category_delete
                    if (preg_match('#^/admin/category/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                            $allow = array_merge($allow, array('POST', 'DELETE'));
                            goto not_admin_category_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_category_delete')), array (  '_controller' => 'App\\MainBundle\\Controller\\CategoryController::deleteAction',));
                    }
                    not_admin_category_delete:

                }

            }

            if (0 === strpos($pathinfo, '/admin/article')) {
                // admin_article
                if (rtrim($pathinfo, '/') === '/admin/article') {
                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'admin_article');
                    }

                    return array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::indexAction',  '_route' => 'admin_article',);
                }

                // admin_article_show
                if (preg_match('#^/admin/article/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_article_show')), array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::showAction',));
                }

                // admin_article_new
                if ($pathinfo === '/admin/article/new') {
                    return array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::newAction',  '_route' => 'admin_article_new',);
                }

                // admin_article_create
                if ($pathinfo === '/admin/article/create') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_admin_article_create;
                    }

                    return array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::createAction',  '_route' => 'admin_article_create',);
                }
                not_admin_article_create:

                // admin_article_edit
                if (preg_match('#^/admin/article/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_article_edit')), array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::editAction',));
                }

                // admin_article_update
                if (preg_match('#^/admin/article/(?P<id>[^/]++)/update$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'PUT'))) {
                        $allow = array_merge($allow, array('POST', 'PUT'));
                        goto not_admin_article_update;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_article_update')), array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::updateAction',));
                }
                not_admin_article_update:

                // admin_article_delete
                if (preg_match('#^/admin/article/(?P<id>[^/]++)/delete$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('POST', 'DELETE'))) {
                        $allow = array_merge($allow, array('POST', 'DELETE'));
                        goto not_admin_article_delete;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'admin_article_delete')), array (  '_controller' => 'App\\MainBundle\\Controller\\ArticleController::deleteAction',));
                }
                not_admin_article_delete:

            }

            // contact
            if ($pathinfo === '/admin') {
                return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::adminAction',  '_route' => 'contact',);
            }

        }

        // home
        if ($pathinfo === '/home') {
            return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::homeAction',  '_route' => 'home',);
        }

        // list
        if ($pathinfo === '/list') {
            return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::listAction',  '_route' => 'list',);
        }

        // show
        if ($pathinfo === '/show') {
            return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::showAction',  '_route' => 'show',);
        }

        // menu
        if ($pathinfo === '/menu') {
            return array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::menuAction',  '_route' => 'menu',);
        }

        // category
        if (0 === strpos($pathinfo, '/category') && preg_match('#^/category/(?P<link>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'category')), array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::categoryAction',));
        }

        // article
        if (0 === strpos($pathinfo, '/article') && preg_match('#^/article/(?P<link>[^/]++)$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => 'article')), array (  '_controller' => 'App\\MainBundle\\Controller\\DefaultController::articleAction',));
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
