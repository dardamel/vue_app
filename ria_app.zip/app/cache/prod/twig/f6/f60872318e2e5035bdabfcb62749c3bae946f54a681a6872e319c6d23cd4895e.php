<?php

/* AppMainBundle:Admin:index.html.twig */
class __TwigTemplate_539aeeb26a9333b1f5cd5639e47cb6b08900967c1f4ed4d0d87e840f62e49d8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<h1>Zarządzanie</h1>

<a href=\"";
        // line 3
        echo $this->env->getExtension('routing')->getPath("admin_article");
        echo "\">Artykuły</a><br />
<a href=\"";
        // line 4
        echo $this->env->getExtension('routing')->getPath("admin_kategorie");
        echo "\">Kategorie</a><br/>
<a href=\"";
        // line 5
        echo $this->env->getExtension('routing')->getPath("admin_contact");
        echo "\">Kontakt</a><br/>";
    }

    public function getTemplateName()
    {
        return "AppMainBundle:Admin:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 5,  27 => 4,  23 => 3,  19 => 1,);
    }
}
/* <h1>Zarządzanie</h1>*/
/* */
/* <a href="{{ path('admin_article') }}">Artykuły</a><br />*/
/* <a href="{{ path('admin_kategorie') }}">Kategorie</a><br/>*/
/* <a href="{{ path('admin_contact') }}">Kontakt</a><br/>*/
